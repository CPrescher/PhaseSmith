"""PhaseSmith wall-clock throughput over the full agreement-qualified inorganic cohort.

Run with the same PYTHONPATH and BLAS caps as run.py. One persistent process
owns each fixed, round-robin shard. Threads use the same shards in one process.
Time from dispatch until all results complete, with CIFs and generators prepared.
"""
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from contextlib import ExitStack
import argparse
from pathlib import Path
from time import perf_counter
import gc
import hashlib
import json
import multiprocessing
import statistics
import sys

import numpy as np
import phasesmith as ps

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
if (HERE/'protocol').is_dir():
    sys.path.insert(0, str(HERE/'protocol'))
from inorganic import bench, native_common_inputs

SCAN = ps.CwTwoThetaRange(*bench.LIMITS, bench.WAVE)
FACTORS = ps.XrayNonResonant()
LP = ps.BraggBrentanoUnpolarizedLp(bench.WAVE)
MODES = ('serial1', 'serial8', 'threads8x1', 'processes8x1')

def load(entries):
    models = []
    for entry in entries:
        path = Path(entry['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
        structure, _, _ = native_common_inputs(path)
        models.append((structure, ps.PreparedReflectionGenerator(structure.space_group)))
    return models

def calculate(models, policy, verify):
    peaks = 0
    hashes = []
    for structure, generator in models:
        refs = generator.generate(structure.cell, SCAN)
        result = ps.calculate_structure_factor_values(structure, refs.hkl, refs.multiplicity,
                    FACTORS, correction=LP, execution=policy)
        angles = 2 * np.rad2deg(np.arcsin(bench.WAVE / (2 * refs.d_spacing_angstrom)))
        x, y = bench.merge_sticks(angles, result.integrated_intensity)
        peaks += len(x)
        if verify:
            digest = hashlib.sha256(x.tobytes())
            digest.update(y.tobytes())
            hashes.append(digest.hexdigest())
    return peaks, hashes

def prepare_worker(entries):
    global worker_models, worker_policy
    worker_models = load(entries)
    worker_policy = ps.ExecutionPolicy(threads=1)
    gc.disable()
    return len(worker_models)

def run_worker(verify):
    return calculate(worker_models, worker_policy, verify)

def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cif-dir', type=Path, help='directory of original <COD ID>.cif files when running from the results archive')
    args = parser.parse_args()
    assert ps._core.BUILD_MODE == 'release'
    if (HERE/'candidate').is_dir():
        assert HERE/'candidate' in Path(ps._core.__file__).resolve().parents
    rows = [json.loads(line) for line in (HERE/'results.jsonl').read_text().splitlines()]
    assert len(rows) == 5552
    manifest = HERE/'inorganic-inputs.json' if args.cif_dir else HERE.parent/'inorganic-manifest.json'
    inventory = {r['id']: r for r in json.loads(manifest.read_text())}
    if args.cif_dir:
        for key, entry in inventory.items():
            entry['path'] = str(args.cif_dir / (key+'.cif'))
    entries = [inventory[r['id']] for r in rows if r.get('agreement', {}).get('passed')]
    shards = [entries[i::8] for i in range(8)]
    models = [load(shard) for shard in shards]
    policy1, policy8 = [ps.ExecutionPolicy(threads=n) for n in (1,8)]
    thread_policies = [ps.ExecutionPolicy(threads=1) for _ in shards]
    with ExitStack() as stack:
        threads = stack.enter_context(ThreadPoolExecutor(8))
        processes = [stack.enter_context(ProcessPoolExecutor(1, mp_context=multiprocessing.get_context('spawn'))) for _ in shards]
        futures = [executor.submit(prepare_worker, shard) for executor, shard in zip(processes,shards)]
        assert [f.result() for f in futures] == list(map(len,shards))
        gc.disable()
        def evaluate(mode, verify):
            if mode in ('serial1','serial8'):
                return [calculate(part, policy1 if mode=='serial1' else policy8, verify) for part in models]
            if mode == 'threads8x1':
                jobs = [threads.submit(calculate, part, policy, verify) for part, policy in zip(models,thread_policies)]
            else:
                jobs = [pool.submit(run_worker, verify) for pool in processes]
            return [job.result() for job in jobs]
        reference = evaluate('serial1', True)
        for mode in MODES[1:]:
            assert evaluate(mode, True) == reference, mode
        counts = [(n, []) for n, _ in reference]
        samples = {mode: [] for mode in MODES}
        orders = []
        for i in range(4):
            order = MODES[i:] + MODES[:i]
            orders.append(order)
            for mode in order:
                start = perf_counter()
                result = evaluate(mode, False)
                elapsed = perf_counter() - start
                assert result == counts
                samples[mode].append(elapsed)
                print(mode, len(samples[mode]), elapsed, flush=True)
    data = dict(n=len(entries), peaks=sum(n for n,_ in counts), modes=MODES, orders=orders,
                input_order='agreement-qualified rows of results.jsonl distributed as rows[i::8]',
                batch_wall_seconds=samples, median_seconds={m:statistics.median(s) for m,s in samples.items()},
                verified='bitwise identical angles and intensities for every file in all four warm-up modes')
    (HERE/'batch.json').write_text(json.dumps(data,indent=2)+'\n')

if __name__ == '__main__':
    run()
