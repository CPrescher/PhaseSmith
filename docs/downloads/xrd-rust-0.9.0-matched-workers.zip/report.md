# Released PhaseSmith batch API versus xrd-rust

On the corrected inorganic COD collection, PhaseSmith 0.9.0 finished the 5,319 computable patterns in **8.18 s** with its default four worker threads. Stock xrd-rust 0.3.5 took **504.93 s** with the same four outer threads, a **61.74×** batch throughput advantage on this Apple M4 Pro.

| Outer workers | Completed pairs | PhaseSmith (s) | xrd-rust (s) | Speedup | PhaseSmith patterns/s | xrd-rust patterns/s |
|---|---:|---:|---:|---:|---:|---:|
| Inline | 3 | 21.04 | 493.48 | 23.45× | 252.8 | 10.8 |
| 2 threads | 2 | 12.07 | 500.17 | 41.43× | 440.6 | 10.6 |
| 4 threads | 2 | 8.18 | 504.93 | 61.74× | 650.3 | 10.5 |
| 8 threads | 2 | 7.35 | 504.06 | 68.59× | 723.7 | 10.6 |
| 2 processes | 2 | 15.93 | 217.11 | 13.63× | 333.9 | 24.5 |
| 4 processes | 2 | 8.96 | 116.92 | 13.04× | 593.3 | 45.5 |
| 8 processes | 3 | 6.07 | 74.03 | 12.19× | 876.2 | 71.9 |

![Elapsed time by outer worker count](worker-scaling.png)

Lines join the available medians. Bands span the observed minima and maxima. Both lines for each library share the inline baseline at one worker.

The full-batch rows include all 87 previously documented disagreements. We also timed the default four-thread configuration on the 5,232 agreement-qualified structures alone. PhaseSmith took **8.12 s** and xrd-rust **497.80 s**, a **61.28×** speedup.

## Inputs and numerical validation

All 5,552 CIF checksums were verified and all input pairs were rebuilt in the frozen collection order. Both libraries received the same cell, setting, neutral atoms and occupancies with zero displacements. The scan covered discrete sticks over 2–60° in 2θ at 0.71073 Å. The common input builder encountered 91 strict CIF rejections, 104 cell-only files and 38 shared-model construction failures. Error strings reproduced the archived run. Both engines completed all 5,319 constructed inputs.

Agreement was evaluated anew using peak positions within 0.00001°, correlation ≥0.999 and no unmatched peak reaching 0.1% of the strongest peak. All prior agreement metrics reproduced within relative tolerance 1e−11 and absolute tolerance 1e−12, with the same 87 COD IDs outside the gate. Every timed position and intensity array matched that engine's reference output byte for byte in input order.

## Timing protocol

Both programs ran on the same M4 Pro, macOS 26.6.2 and Python 3.13.7. The installed Python and native code was checked against the PyPI wheels. PhaseSmith's calculate_powder_sticks_batch handled the entire batch in one public call. The four-thread row used its default arguments. We mapped xrd-rust's public get_pattern over the same inputs, using its serial SIMD kernel with one internal thread and unscaled intensities. The adapter returned its angle and intensity arrays. Its public call also constructs reflection metadata. One-worker calls ran inline. Threaded and spawned-process calls created a fresh pool for each timed batch. Both used one task per structure. The programs ran consecutively with rotating configuration order and alternating library order across repeats. BLAS, OpenMP and Rayon thread limits were set to one.

The benchmark stopped during the third two-thread xrd-rust run at the user's request. The interrupted call is excluded. Each cell gives the median elapsed wall time from completed paired calls (two or three per setting) with the parent packages already imported. Timing includes pool startup, dispatch, generation, calculation, gathering the results, process input/output transfer and shutdown. CIF parsing, construction of the equivalent input objects, and numerical verification were outside the timer. The speedup is the ratio of full-batch medians. It measures throughput on this hardware. The earlier per-file benchmark measured latency with worker threads inside individual calculations.

## Reproduction

Install the pinned packages from requirements.txt. Run compare.py with the prior 47a238b results archive and the corrected CIF directory as its two arguments. Set OPENBLAS_NUM_THREADS, OMP_NUM_THREADS, MKL_NUM_THREADS, VECLIB_MAXIMUM_THREADS and RAYON_NUM_THREADS to 1 in the parent environment. For a fresh run use an empty output directory containing the scripts, protocol directory and requirements. The timings and audit files allow an interrupted run to resume. Raw timings are in seconds.
