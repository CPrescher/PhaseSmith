from collections import Counter, defaultdict
from pathlib import Path
import csv, hashlib, json, math, statistics
from zipfile import ZipFile, ZIP_DEFLATED
from plot import render

out=Path(__file__).resolve().parent
read=lambda name: json.loads((out/name).read_text())
lines=lambda name: [json.loads(l) for l in (out/name).read_text().splitlines()]
env=read('environment.json')
audit=lines('agreement.jsonl')
errors=read('excluded.json')
rows=lines('timings.jsonl')
assert env['driver_sha256']==hashlib.sha256((out/'compare.py').read_bytes()).hexdigest()
assert len({r['id'] for r in audit+errors})==5552
assert len(audit)==5319 and len(errors)==233
assert sum(r['agreement']['passed'] for r in audit)==5232
assert len(rows)==len({(r['engine'],r['cohort'],r['backend'],r['workers'],r['repeat']) for r in rows})
timings=defaultdict(list)
for r in rows:
    assert math.isfinite(r['seconds']) and r['seconds']>0
    assert r['n']==(5319 if r['cohort']=='all' else 5232)
    timings[r['cohort'],r['backend'],r['workers'],r['engine']].append(r['seconds'])
assert all(2 <= len(v) <= 3 for v in timings.values())
modes=[('threads',1),('threads',2),('threads',4),('threads',8),('processes',2),('processes',4),('processes',8)]
stats=[]
for cohort,cases,n in [('all',modes,5319),('qualified',[('threads',4)],5232)]:
    for backend,workers in cases:
        paired = sorted({r['repeat'] for r in rows if (r['cohort'],r['backend'],r['workers'],r['engine'])==(cohort,backend,workers,'ps')} & {r['repeat'] for r in rows if (r['cohort'],r['backend'],r['workers'],r['engine'])==(cohort,backend,workers,'xr')})
        ps,xr=[statistics.median(r['seconds'] for r in rows if (r['cohort'],r['backend'],r['workers'],r['engine'])==(cohort,backend,workers,e) and r['repeat'] in paired) for e in ('ps','xr')]
        stats.append(dict(cohort=cohort,patterns=n,paired_repeats=len(paired),backend=backend,workers=workers,ps_seconds=ps,xr_seconds=xr,
                          speedup=xr/ps,ps_patterns_per_second=n/ps,xr_patterns_per_second=n/xr))
with (out/'summary.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=stats[0]); w.writeheader(); w.writerows(stats)
def row(s):
    mode='Inline' if s['workers']==1 else f"{s['workers']} {s['backend']}"
    return f"| {mode} | {s['paired_repeats']} | {s['ps_seconds']:.2f} | {s['xr_seconds']:.2f} | {s['speedup']:.2f}× | {s['ps_patterns_per_second']:.1f} | {s['xr_patterns_per_second']:.1f} |"
default=stats[2];qualified=stats[-1]
exclusions=Counter(r['stage'] for r in errors)
body=f"""# Released PhaseSmith batch API versus xrd-rust

On the corrected inorganic COD collection, PhaseSmith 0.9.0 finished the 5,319 computable patterns in **{default['ps_seconds']:.2f} s** with its default four worker threads. Stock xrd-rust 0.3.5 took **{default['xr_seconds']:.2f} s** with the same four outer threads, a **{default['speedup']:.2f}×** batch throughput advantage on this Apple M4 Pro.

| Outer workers | Completed pairs | PhaseSmith (s) | xrd-rust (s) | Speedup | PhaseSmith patterns/s | xrd-rust patterns/s |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(row(s) for s in stats[:-1])}

![Elapsed time by outer worker count](worker-scaling.png)

Lines join the available medians. Bands span the observed minima and maxima. Both lines for each library share the inline baseline at one worker.

The full-batch rows include all 87 previously documented disagreements. We also timed the default four-thread configuration on the 5,232 agreement-qualified structures alone. PhaseSmith took **{qualified['ps_seconds']:.2f} s** and xrd-rust **{qualified['xr_seconds']:.2f} s**, a **{qualified['speedup']:.2f}×** speedup.

## Inputs and numerical validation

All 5,552 CIF checksums were verified and all input pairs were rebuilt in the frozen collection order. Both libraries received the same cell, setting, neutral atoms and occupancies with zero displacements. The scan covered discrete sticks over 2–60° in 2θ at 0.71073 Å. The common input builder encountered {exclusions['strict CIF rejection']} strict CIF rejections, {exclusions['cell only']} cell-only files and {exclusions['shared input construction']} shared-model construction failures. Error strings reproduced the archived run. Both engines completed all 5,319 constructed inputs.

Agreement was evaluated anew using peak positions within 0.00001°, correlation ≥0.999 and no unmatched peak reaching 0.1% of the strongest peak. All prior agreement metrics reproduced within relative tolerance 1e−11 and absolute tolerance 1e−12, with the same 87 COD IDs outside the gate. Every timed position and intensity array matched that engine's reference output byte for byte in input order.

## Timing protocol

Both programs ran on the same M4 Pro, macOS 26.6.2 and Python 3.13.7. The installed Python and native code was checked against the PyPI wheels. PhaseSmith's calculate_powder_sticks_batch handled the entire batch in one public call. The four-thread row used its default arguments. We mapped xrd-rust's public get_pattern over the same inputs, using its serial SIMD kernel with one internal thread and unscaled intensities. The adapter returned its angle and intensity arrays. Its public call also constructs reflection metadata. One-worker calls ran inline. Threaded and spawned-process calls created a fresh pool for each timed batch. Both used one task per structure. The programs ran consecutively with rotating configuration order and alternating library order across repeats. BLAS, OpenMP and Rayon thread limits were set to one.

The benchmark stopped during the third two-thread xrd-rust run at the user's request. The interrupted call is excluded. Each cell gives the median elapsed wall time from completed paired calls (two or three per setting) with the parent packages already imported. Timing includes pool startup, dispatch, generation, calculation, gathering the results, process input/output transfer and shutdown. CIF parsing, construction of the equivalent input objects, and numerical verification were outside the timer. The speedup is the ratio of full-batch medians. It measures throughput on this hardware. The earlier per-file benchmark measured latency with worker threads inside individual calculations.

## Reproduction

Install the pinned packages from requirements.txt. Run compare.py with the prior 47a238b results archive and the corrected CIF directory as its two arguments. Set OPENBLAS_NUM_THREADS, OMP_NUM_THREADS, MKL_NUM_THREADS, VECLIB_MAXIMUM_THREADS and RAYON_NUM_THREADS to 1 in the parent environment. For a fresh run use an empty output directory containing the scripts, protocol directory and requirements. The timings and audit files allow an interrupted run to resume. Raw timings are in seconds.
"""
(out/'report.md').write_text(body)
render(out)
with ZipFile(out/'released-090-matched-workers.zip','w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for n in ('report.md','summary.csv','timings.jsonl','agreement.jsonl','excluded.json','environment.json',
              'requirements.txt','worker-scaling.png','plot.py','compare.py','summarize.py','protocol/run_cod.py','protocol/inorganic.py'):
        z.write(out/n,n)
