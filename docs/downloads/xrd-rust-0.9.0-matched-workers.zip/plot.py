"""Render all complete batch times and their run-to-run ranges."""
import json
from pathlib import Path
from statistics import median
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter

def render(out):
    runs=[json.loads(l) for l in (out/'timings.jsonl').read_text().splitlines()]
    fig, ax=plt.subplots(figsize=(7.6,4.3),layout='constrained')
    for engine,color,label in [('xr','#a44c2e','xrd-rust'),('ps','#146e78','PhaseSmith')]:
        for backend,linestyle,marker in [('threads','-','o'),('processes','--','s')]:
            med=[];low=[];high=[]
            for n in (1,2,4,8):
                vals=[r['seconds'] for r in runs if r['cohort']=='all' and r['engine']==engine and r['workers']==n and r['backend']==('threads' if n==1 else backend)]
                assert 2<=len(vals)<=3
                med.append(median(vals));low.append(min(vals));high.append(max(vals))
            ax.plot([1,2,4,8],med,linestyle=linestyle,marker=marker,label=f'{label}, {backend}',color=color,markersize=5,linewidth=1.8)
            ax.fill_between([1,2,4,8],low,high,color=color,alpha=.09)
    ax.set(xscale='log',yscale='log',xlabel='Outer workers (one calculation thread per structure)',ylabel='Elapsed time for 5,319 patterns (s)',
           title='Full corrected inorganic collection')
    ax.xaxis.set_major_locator(FixedLocator([1,2,4,8]));ax.yaxis.set_major_locator(FixedLocator([5,10,20,50,100,200,500]))
    for axis in [ax.xaxis,ax.yaxis]:
        axis.set_major_formatter(FuncFormatter(lambda v,pos:f'{v:g}'))
        axis.set_minor_locator(FixedLocator([]))
    ax.grid(axis='y',alpha=.17);ax.spines[['top','right']].set_visible(False)
    ax.legend(ncols=2,loc='upper center',bbox_to_anchor=(.5,-.16),frameon=False)
    fig.savefig(out/'worker-scaling.png',dpi=170)
    plt.close(fig)
if __name__=='__main__':
    render(Path(__file__).resolve().parent)
