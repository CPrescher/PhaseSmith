"""Benchmark current release wheels on the frozen sample.json draw."""
import argparse
from collections import Counter
from fractions import Fraction
import gc
import hashlib
import json
from pathlib import Path
from time import perf_counter_ns
import traceback

import gemmi
import numpy as np
import phasesmith as ps
from pymatgen.core import Lattice, Structure
from xrd_rust_calculator import XRDCalculatorRust

ROOT = Path(__file__).resolve().parent
WAVE = 0.71073
LIMITS = (2., 60.)
ANGLE_TOL = 1.e-5
SIGNIFICANT = 0.1  # Percent of strongest peak
MIN_CORR = .999
NREP = 3
MODES = ('ps1', 'xr1', 'ps2', 'xr8', 'ps8')

def structures(path):
    block = gemmi.cif.read(str(path)).sole_block()
    small = gemmi.make_small_structure_from_block(block)
    raw_ops = block.find_values('_space_group_symop_operation_xyz') or block.find_values('_symmetry_equiv_pos_as_xyz')
    ops = ([gemmi.Op(gemmi.cif.as_string(value)) for value in raw_ops]
           if raw_ops else list(small.spacegroup.operations()))
    group = ps.SpaceGroup([ps.SymmetryOperation(np.array(op.rot)//op.DEN,
        [Fraction(n, op.DEN) for n in op.tran]) for op in ops])
    sites = []
    for i, site in enumerate(small.sites):
        symbol = site.element.name
        xyz = tuple(site.fract)
        # The deposited LaCrGe3 CIF gives La as .3333,.6667,.75 on a
        # special position. Exact thirds recover Z=2 and the reported formula.
        if path.stem == '4002001' and site.label == 'La1':
            assert xyz == (.3333, .6667, .75)
            xyz = (1/3, 2/3, .75)
        sites.append(ps.AtomSite(str(i), site.label, symbol, symbol,
                                 xyz, site.occ, 0.))
    cell = small.cell.parameters
    source = ps.CrystalStructure(path.stem, path.stem, ps.UnitCell(*cell), group, tuple(sites))
    expanded = group.expand_sites([s.fractional_xyz for s in sites], tolerance=1.e-10)
    species = [{sites[i].element_symbol: sites[i].occupancy} for i in expanded.source_site]
    other = Structure(Lattice.from_parameters(*cell), species, expanded.fractional_xyz)
    info = dict(system=group.crystal_system, space_group=small.spacegroup_hm, volume=small.cell.volume,
                asymmetric_sites=len(sites), expanded_sites=len(other), cell=cell,
                partial_occupancy=any(s.occupancy != 1 for s in sites),
                elements=sorted({s.element_symbol for s in sites}))
    return source, other, info

def merge_sticks(angles, values):
    # Anchor each cluster on its lowest angle; do not chain nearby peaks.
    order = np.argsort(angles, kind='stable')
    x, y = angles[order], values[order]
    cuts = np.r_[0, np.flatnonzero(np.diff(x) >= ANGLE_TOL) + 1]
    ends = np.r_[cuts[1:] - 1, len(x) - 1]
    more = []
    for a, b in zip(cuts[x[ends]-x[cuts] >= ANGLE_TOL], ends[x[ends]-x[cuts] >= ANGLE_TOL]):
        start = a
        for k in range(a+1, b+1):
            if x[k] - x[start] >= ANGLE_TOL:
                more.append(k)
                start = k
    if more:
        cuts = np.sort(np.r_[cuts, more])
    return x[cuts], np.add.reduceat(y, cuts)

def agreement(a, b):
    # Two sorted spectra. Pair closest candidates within tolerance, one-to-one.
    x, y = a
    order = np.argsort(b[0], kind='stable')
    u, v = b[0][order], b[1][order]
    y, v = 100*y / max(y), 100*v / max(v)
    lo, hi = np.searchsorted(u, x-ANGLE_TOL), np.searchsorted(u, x+ANGLE_TOL, side='right')
    pairs = sorted((abs(x[i]-u[j]), i, j) for i in range(len(x)) for j in range(lo[i], hi[i]))
    used_x, used_u = np.zeros(len(x), bool), np.zeros(len(u), bool)
    yi, vi, errors = [], [], []
    for delta, i, j in pairs:
        if not used_x[i] and not used_u[j]:
            used_x[i] = used_u[j] = True
            yi.append(y[i]); vi.append(v[j]); errors.append(delta)
    left = np.r_[yi, y[~used_x], np.zeros(np.sum(~used_u))]
    right = np.r_[vi, np.zeros(np.sum(~used_x)), v[~used_u]]
    corr = float(np.corrcoef(left, right)[0,1])
    miss_x, miss_u = [int(np.sum(mask & (intens >= SIGNIFICANT))) for mask, intens in
                       [(~used_x, y), (~used_u, v)]]
    return dict(ps_sticks=len(x), xr_sticks=len(u), paired=len(yi),
                unmatched_significant_ps=miss_x, unmatched_significant_xr=miss_u,
                correlation=corr, max_matched_angle_error_deg=max(errors,default=None),
                intensity_rmse_pctmax=float(np.sqrt(np.mean((left-right)**2))),
                max_intensity_difference_pctmax=float(np.max(np.abs(left-right))),
                passed=bool(corr >= MIN_CORR and not (miss_x or miss_u)))

def benchmark(entry, index, row):
    path = ROOT/'cifs'/f"{entry['id']}.cif"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256']
    structure, other, info = structures(path)
    row.update(info)
    gen = ps.PreparedReflectionGenerator(structure.space_group)
    scan = ps.CwTwoThetaRange(*LIMITS, WAVE)
    factors = ps.XrayNonResonant()
    lp = ps.BraggBrentanoUnpolarizedLp(WAVE)
    policies = {n: ps.ExecutionPolicy(threads=n) for n in (1,2,8)}
    xr = {n: XRDCalculatorRust(wavelength=WAVE, symprec=0, use_simd=True, parallel=n>1, num_threads=n) for n in (1,8)}
    def evaluate(mode):
        n = int(mode[2:])
        if mode.startswith('xr'):
            return xr[n].get_pattern(other, scaled=False, two_theta_range=LIMITS)
        refs = gen.generate(structure.cell, scan)
        out = ps.calculate_structure_factor_values(structure, refs.hkl, refs.multiplicity,
                    factors, correction=lp, execution=policies[n])
        angles = 2*np.rad2deg(np.arcsin(WAVE/(2*refs.d_spacing_angstrom)))
        return merge_sticks(angles, out.integrated_intensity)

    samples = {m: [] for m in MODES}
    warm = {}
    for rep in range(NREP+1):
        order = np.roll(MODES, -(index+rep)%len(MODES))
        for mode in order:
            gc.disable()
            try:
                t = perf_counter_ns()
                result = evaluate(mode)
                elapsed = (perf_counter_ns() - t) / 1.e6
            finally:
                gc.enable()
            if rep:
                samples[mode].append(elapsed)
            else:
                warm[mode] = (result.x.copy(), result.y.copy()) if mode.startswith('xr') else result
            del result
        if not rep:
            for first, second in [('ps1','ps2'), ('ps1','ps8'), ('xr1','xr8')]:
                for a, b in zip(warm[first], warm[second]):
                    np.testing.assert_allclose(a, b, rtol=1.e-12, atol=1.e-12)
            row['agreement'] = agreement(warm['ps1'],warm['xr1'])
            del warm
    row['samples_ms'] = samples
    row['medians_ms'] = {k: float(np.median(v)) for k,v in samples.items()}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', default='cod-results.jsonl')
    parser.add_argument('--only', help='Run one selected COD entry for diagnostics')
    args = parser.parse_args()
    dest = ROOT/args.out
    complete = {json.loads(line)['id'] for line in dest.read_text().splitlines()} if dest.exists() else set()
    assert ps._core.BUILD_MODE == 'release'
    entries = json.loads((ROOT/'sample.json').read_text())['entries']
    for index, entry in enumerate(entries):
        if (args.only and entry['id'] != args.only) or entry['id'] in complete:
            continue
        print(f"{index+1}/100 {entry['id']}", flush=True)
        row = dict(id=entry['id'])
        try:
            benchmark(entry, index, row)
        except Exception:
            row['error'] = traceback.format_exc()
            print(row['error'], flush=True)
        with dest.open('a') as f:
            f.write(json.dumps(row, allow_nan=False)+'\n')
