"""Compare public CIF front ends, and time the frozen pattern protocol on the inorganic panel."""
import gc,hashlib,json,statistics,sys,time,warnings
from pathlib import Path

import phasesmith as ps
from phasesmith.io.cif import read_cif
from pymatgen.core import Lattice,Structure
from pymatgen.io.cif import CifParser
import numpy as np

out=Path(__file__).resolve().parent
sys.path.insert(0,'/Users/clemens/ChatGPT/PhaseSmith/xrd-rust-cod-20261120')
import run_cod as bench

def native_common_inputs(path):
    original=read_cif(path,strict=True).structure
    if not original.sites:
        raise ValueError('strict import yielded a cell without atom sites')
    # The powder benchmark uses the same neutral species, coordinates, occupancies,
    # cell, and zero displacement for both calculators. Keep the deposited setting.
    sites=tuple(ps.AtomSite(a.site_id,a.source_label,a.element_symbol,a.element_symbol,
                            a.fractional_xyz,a.occupancy,0.) for a in original.sites)
    common=ps.CrystalStructure(original.structure_id,original.name,original.cell,original.space_group,sites)
    expanded=common.space_group.expand_sites([s.fractional_xyz for s in sites],tolerance=1.e-10)
    species=[{sites[i].element_symbol:sites[i].occupancy} for i in expanded.source_site]
    lattice=Lattice.from_parameters(*common.cell.as_tuple())
    other=Structure(lattice,species,expanded.fractional_xyz)
    info=dict(system=common.space_group.crystal_system,volume=lattice.volume,asymmetric_sites=len(sites),
              expanded_sites=len(other),cell=common.cell.as_tuple(),partial_occupancy=any(s.occupancy!=1 for s in sites),
              elements=sorted({s.element_symbol for s in sites}))
    return common,other,info

def read_ps(path):
    return len(read_cif(path,strict=True).structure.sites)

def read_pm(path):
    structures=CifParser(path).parse_structures(primitive=False)
    if len(structures)!=1:raise ValueError(f'expected one structure, got {len(structures)}')
    return len(structures[0])

def timed_read(path,index):
    row={'id':path.stem}
    for rep in range(4):
        for name,fn in [('ps',read_ps),('pymatgen',read_pm)][::1 if (index+rep)%2==0 else -1]:
            result=row.setdefault(name,{'samples_ms':[]})
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                gc.disable()
                try:
                    start=time.perf_counter_ns()
                    try:
                        sites=fn(path)
                    except Exception as exc:
                        elapsed=time.perf_counter_ns()-start
                        assert 'sites' not in result
                        result.update(error=str(exc),exception=type(exc).__name__)
                    else:
                        elapsed=time.perf_counter_ns()-start
                        assert 'error' not in result
                        result['sites']=sites
                finally:
                    gc.enable()
            if rep: result['samples_ms'].append(elapsed/1e6)
    for name in ('ps','pymatgen'):
        row[name]['median_ms']=statistics.median(row[name]['samples_ms'])
    return row

if __name__=='__main__':
    assert ps._core.BUILD_MODE=='release'
    inventory={r['id']:r for r in json.loads((out/'inorganic-manifest.json').read_text())}
    panel=json.loads((out/'panel.json').read_text())
    mode=sys.argv[1]
    assert mode in ('patterns','imports')
    ids=panel['sample']+panel['supplement'] if mode=='patterns' else list(inventory)
    bench.ROOT=out/'inorganic-panel'
    bench.structures=native_common_inputs
    output=out/f'inorganic-{mode}.jsonl'
    done={json.loads(l)['id'] for l in output.read_text().splitlines()} if output.exists() else set()
    with output.open('a') as f:
        for n,i in enumerate(ids):
            if i in done:continue
            entry=inventory[i]
            path=Path(entry['path'])
            assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
            if mode=='patterns':
                row={'id':i}
                try:bench.benchmark(entry,n,row)
                except Exception as exc:row.update(error=str(exc),exception=type(exc).__name__)
            else:row=timed_read(path,n)
            f.write(json.dumps(row,allow_nan=False)+'\n')
            f.flush()
            if mode=='patterns' or n%100==0:print(n+1,len(ids),i,row.get('error',''),flush=True)
