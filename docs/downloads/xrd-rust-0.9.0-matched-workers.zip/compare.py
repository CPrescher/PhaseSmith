"""Matched outer-worker, one-shot powder-stick batch benchmark. See report.md."""
import argparse
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import csv
from functools import lru_cache
import hashlib
import io
import json
import math
import multiprocessing
import os
from pathlib import Path
import sys
import time
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
WAVE, LIMITS = 0.71073, (2., 60.)
MODES = [('threads', 1), ('threads', 2), ('threads', 4), ('threads', 8),
         ('processes', 2), ('processes', 4), ('processes', 8)]
def sha(data):
    return hashlib.sha256(data).hexdigest()

@lru_cache(maxsize=1)
def xr_calculator():
    from xrd_rust_calculator import XRDCalculatorRust
    return XRDCalculatorRust(wavelength=WAVE, symprec=0, parallel=False, num_threads=1, use_simd=True)

def xr_one(model):
    pattern = xr_calculator().get_pattern(model, scaled=False, two_theta_range=LIMITS)
    # Public XRD-Rust returns extra reflection metadata. Return the same pair of arrays.
    return pattern.x, pattern.y

def xr_batch(models, backend, workers):
    if workers == 1:
        return tuple(map(xr_one, models))
    if backend == 'threads':
        with ThreadPoolExecutor(max_workers=workers) as pool:
            return tuple(pool.map(xr_one, models))
    with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context('spawn')) as pool:
        return tuple(pool.map(xr_one, models))

def check_env():
    import importlib.metadata as md
    from urllib.request import urlopen
    import phasesmith as ps
    import platform
    assert ps.__version__ == '0.9.0' and ps._core.BUILD_MODE == 'release'
    assert md.version('xrd-rust') == '0.3.5'
    packages = {}
    for name in ('phasesmith','xrd-rust'):
        dist = md.distribution(name)
        with urlopen(f'https://pypi.org/pypi/{name}/{dist.version}/json', timeout=30) as response:
            downloads = json.load(response)['urls']
        tag = next(t for t in dist.read_text('WHEEL').splitlines() if t.startswith('Tag: '))[5:]
        artifact, = [d for d in downloads if d['filename'].endswith('-'+tag+'.whl')]
        with urlopen(artifact['url'], timeout=40) as response:
            wheel=response.read()
        assert sha(wheel)==artifact['digests']['sha256']
        with ZipFile(io.BytesIO(wheel)) as z:
            for entry in z.namelist():
                if entry.endswith(('.py','.so','.dylib')):
                    assert z.read(entry)==dist.locate_file(entry).read_bytes(),entry
        packages[name]=dict(version=dist.version,wheel=artifact['filename'],sha256=sha(wheel))
    limits={key:os.environ[key] for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','OPENBLAS_NUM_THREADS','RAYON_NUM_THREADS')}
    assert set(limits.values())=={'1'}
    return dict(packages=packages,platform=platform.platform(),python=platform.python_version(),
                dependencies={k:md.version(k) for k in ('numpy','pymatgen','pymatgen-core','gemmi')},thread_limits=limits)

def comparable(a,b):
    if a is None or b is None: return a is b or (a is not None and math.isnan(a)) or (b is not None and math.isnan(b))
    return a == b or math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-12)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('archive',type=Path)
    parser.add_argument('cifs',type=Path)
    args=parser.parse_args()
    env=check_env()
    sys.path.insert(0,str(HERE/'protocol'))
    import run_cod
    import inorganic
    import phasesmith as ps
    import numpy as np
    assert run_cod is inorganic.bench
    with ZipFile(args.archive) as z:
        for name in ('inorganic.py','run_cod.py'):
            assert z.read('protocol/'+name)==(HERE/'protocol'/name).read_bytes()
        expected={r['id']:r for r in json.loads(z.read('inorganic-inputs.json'))}
        prior=[json.loads(l) for l in z.read('results.jsonl').splitlines()]
        stages={r['COD']:r['outcome'] for r in csv.DictReader(io.StringIO(z.read('per-entry.csv').decode()))}
    assert len(expected)==len(prior)==len(stages)==5552
    env.update(input_archive_sha256=sha(args.archive.read_bytes()),driver_sha256=sha(Path(__file__).read_bytes()),
               host_cpu='Apple M4 Pro', wavelength_angstrom=WAVE, two_theta_deg=LIMITS)
    (HERE/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
    scan=ps.CwTwoThetaRange(*LIMITS,WAVE)
    ids=[]; sources=[]; others=[]; errors=[]; prev={}
    for r in prior:
        key=r['id']; path=args.cifs/(key+'.cif')
        assert sha(path.read_bytes())==expected[key]['sha256']
        try: model,other,info=inorganic.native_common_inputs(path)
        except Exception as e:
            assert str(e)==r.get('error'),(key,str(e),r.get('error'))
            errors.append(dict(id=key,stage=stages[key],error=str(e)))
            continue
        assert 'agreement' in r and info['expanded_sites']==r['expanded_sites']
        sources.append(model); others.append(other); ids.append(key); prev[key]=r['agreement']
    assert len(ids)==5319 and len(errors)==233
    (HERE/'excluded.json').write_text(json.dumps(errors,indent=2)+'\n')
    print('Prepared',len(ids),'structure pairs and verified',len(errors),'exclusions',flush=True)
    def calculate(engine,indexes,backend,n):
        models=[(sources if engine=='ps' else others)[i] for i in indexes]
        start=time.perf_counter()
        if engine=='ps':
            if backend=='threads' and n==4:
                result=ps.calculate_powder_sticks_batch(models,scan)
            else:
                result=ps.calculate_powder_sticks_batch(models,scan,workers=n,backend=backend)
        else:
            result=xr_batch(models,backend,n)
        elapsed=time.perf_counter()-start
        if engine=='ps':
            assert [r.structure_id for r in result]==[m.structure_id for m in models]
            arrays=[(r.two_theta_deg,r.integrated_intensity) for r in result]
        else:
            arrays=result
        assert len(arrays)==len(indexes)
        return elapsed,arrays

    def fingerprint(pair):
        x,y=pair
        assert x.dtype==y.dtype==np.float64 and x.shape==y.shape and x.ndim==1
        h=hashlib.sha256(x.tobytes());h.update(y.tobytes());return h.hexdigest()

    all_indices=list(range(len(ids)))
    audit_path=HERE/'agreement.jsonl'
    if not audit_path.exists():
        # Untimed for speed reporting. Retain outputs to check every pattern using the frozen gate.
        _,ps_arrays=calculate('ps',all_indices,'threads',4)
        _,xr_arrays=calculate('xr',all_indices,'processes',8)
        with audit_path.with_suffix('.tmp').open('w') as f:
            for key,pp,xp in zip(ids,ps_arrays,xr_arrays,strict=True):
                a=run_cod.agreement(pp,xp)
                for field,value in a.items():
                    assert comparable(value,prev[key][field]),(key,field,value,prev[key][field])
                a={k:None if isinstance(v,float) and not math.isfinite(v) else v for k,v in a.items()}
                f.write(json.dumps(dict(id=key,ps=fingerprint(pp),xr=fingerprint(xp),agreement=a),allow_nan=False)+'\n')
        audit_path.with_suffix('.tmp').replace(audit_path)
        del ps_arrays,xr_arrays
    audit=[json.loads(l) for l in audit_path.read_text().splitlines()]
    assert [r['id'] for r in audit]==ids
    good=[i for i,r in enumerate(audit) if r['agreement']['passed']]
    assert len(good)==5232
    print('All 5319 computed patterns audited;',len(good),'qualified.',flush=True)
    times=HERE/'timings.jsonl'
    done={tuple(row[k] for k in ('cohort','repeat','backend','workers','engine')) for row in
          [json.loads(l) for l in times.read_text().splitlines()] } if times.exists() else set()
    for rep in range(3):
        cases=[('all',mode) for mode in MODES]+[('qualified',('threads',4))]
        offset=(3*rep)%len(cases)
        for ci,(cohort,(backend,n)) in enumerate(cases[offset:]+cases[:offset]):
            idx=all_indices if cohort=='all' else good
            for eng in (('ps','xr') if (rep+cases.index((cohort,(backend,n))))%2==0 else ('xr','ps')):
                if (cohort,rep,backend,n,eng) in done: continue
                print('START',cohort,rep+1,backend,n,eng,flush=True)
                elapsed,arrays=calculate(eng,idx,backend,n)
                assert all(fingerprint(pair)==audit[i][eng] for i,pair in zip(idx,arrays,strict=True)),(rep,backend,n,eng)
                del arrays
                record=dict(cohort=cohort,repeat=rep,backend=backend,workers=n,engine=eng,n=len(idx),seconds=elapsed)
                with times.open('a') as f:f.write(json.dumps(record)+'\n')
                print('DONE',round(elapsed,3),flush=True)

if __name__=='__main__':
    main()
